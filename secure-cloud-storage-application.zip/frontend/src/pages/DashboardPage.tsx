import { useState } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useGetUserFiles } from '../hooks/useQueries';
import { useQueryClient } from '@tanstack/react-query';
import Header from '../components/Header';
import FileUploadZone from '../components/FileUploadZone';
import FileList from '../components/FileList';
import EmptyState from '../components/EmptyState';
import { Skeleton } from '@/components/ui/skeleton';

export default function DashboardPage() {
  const { clear, identity } = useInternetIdentity();
  const queryClient = useQueryClient();
  const { data: files, isLoading } = useGetUserFiles();
  const [searchQuery, setSearchQuery] = useState('');

  const handleLogout = async () => {
    await clear();
    queryClient.clear();
  };

  // Get a display name from the principal
  const getUserName = () => {
    if (!identity) return 'User';
    const principal = identity.getPrincipal().toString();
    // Use first 8 characters of principal as display name
    return principal.substring(0, 8);
  };

  const filteredFiles = files?.filter((file) =>
    file.filename.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <Header
        userName={getUserName()}
        onLogout={handleLogout}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="container mx-auto px-4 py-8">
        <div className="mx-auto max-w-6xl space-y-8">
          {/* Upload Zone */}
          <FileUploadZone />

          {/* Files Section */}
          <div>
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-2xl font-semibold">My Files</h2>
              {files && files.length > 0 && (
                <p className="text-sm text-muted-foreground">
                  {filteredFiles?.length || 0} of {files.length} files
                </p>
              )}
            </div>

            {isLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : filteredFiles && filteredFiles.length > 0 ? (
              <FileList files={filteredFiles} />
            ) : searchQuery ? (
              <div className="rounded-lg border border-dashed p-12 text-center">
                <p className="text-muted-foreground">
                  No files found matching "{searchQuery}"
                </p>
              </div>
            ) : (
              <EmptyState />
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>
            © 2025. Built with{' '}
            <span className="text-destructive">❤</span> using{' '}
            <a
              href="https://caffeine.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-foreground hover:underline"
            >
              caffeine.ai
            </a>
          </p>
        </div>
      </footer>
    </div>
  );
}
