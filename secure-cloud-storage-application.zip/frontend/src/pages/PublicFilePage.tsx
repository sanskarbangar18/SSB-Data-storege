import { useGetPublicFileMetadata, useGetFileIdByShareId } from '../hooks/useQueries';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Cloud,
  Download,
  FileText,
  Image,
  Video,
  Music,
  Archive,
  File,
  AlertCircle,
} from 'lucide-react';
import { toast } from 'sonner';

interface PublicFilePageProps {
  shareId: string;
}

export default function PublicFilePage({ shareId }: PublicFilePageProps) {
  const { data: fileMetadata, isLoading, error } = useGetPublicFileMetadata(shareId);
  const { data: fileId } = useGetFileIdByShareId(shareId);

  const formatFileSize = (bytes: bigint) => {
    const numBytes = Number(bytes);
    if (numBytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(numBytes) / Math.log(k));
    return Math.round((numBytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const formatDate = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return <Image className="h-12 w-12" />;
    if (fileType.startsWith('video/')) return <Video className="h-12 w-12" />;
    if (fileType.startsWith('audio/')) return <Music className="h-12 w-12" />;
    if (fileType.includes('pdf')) return <FileText className="h-12 w-12" />;
    if (fileType.includes('zip') || fileType.includes('rar'))
      return <Archive className="h-12 w-12" />;
    return <File className="h-12 w-12" />;
  };

  const getFileIconColor = (fileType: string) => {
    if (fileType.startsWith('image/')) return 'text-blue-500';
    if (fileType.startsWith('video/')) return 'text-purple-500';
    if (fileType.startsWith('audio/')) return 'text-green-500';
    if (fileType.includes('pdf')) return 'text-red-500';
    if (fileType.includes('zip') || fileType.includes('rar')) return 'text-yellow-500';
    return 'text-muted-foreground';
  };

  const handleDownload = async () => {
    if (!fileId || !fileMetadata) return;

    try {
      const response = await fetch(`/blobs/${fileId}`);
      if (!response.ok) {
        throw new Error('Failed to download file');
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileMetadata.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('Download started');
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('Failed to download file');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <header className="mb-12 text-center">
          <div className="mb-4 flex justify-center">
            <div className="rounded-2xl bg-primary/10 p-4">
              <Cloud className="h-12 w-12 text-primary" />
            </div>
          </div>
          <h1 className="mb-2 text-3xl font-bold tracking-tight">SecureCloud</h1>
          <p className="text-muted-foreground">Shared File</p>
        </header>

        {/* Main Content */}
        <div className="mx-auto max-w-2xl">
          {isLoading ? (
            <Card className="shadow-lg">
              <CardHeader>
                <Skeleton className="h-8 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-10 w-full" />
              </CardContent>
            </Card>
          ) : error || !fileMetadata ? (
            <Card className="shadow-lg">
              <CardContent className="py-12 text-center">
                <div className="mb-4 flex justify-center">
                  <div className="rounded-full bg-destructive/10 p-4">
                    <AlertCircle className="h-12 w-12 text-destructive" />
                  </div>
                </div>
                <h2 className="mb-2 text-xl font-semibold">File Not Found</h2>
                <p className="text-muted-foreground">
                  This file doesn't exist or the share link is invalid.
                </p>
              </CardContent>
            </Card>
          ) : (
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">{fileMetadata.filename}</CardTitle>
                <CardDescription>
                  Shared on {formatDate(fileMetadata.uploadTimestamp)}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* File Preview */}
                <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed bg-muted/50 p-12">
                  <div className={`mb-4 ${getFileIconColor(fileMetadata.fileType)}`}>
                    {getFileIcon(fileMetadata.fileType)}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {formatFileSize(fileMetadata.filesize)}
                  </p>
                </div>

                {/* Download Button */}
                <Button onClick={handleDownload} className="w-full" size="lg">
                  <Download className="mr-2 h-5 w-5" />
                  Download File
                </Button>

                {/* Info */}
                <div className="rounded-lg bg-muted/50 p-4 text-center text-sm text-muted-foreground">
                  <p>
                    This file was shared with you via SecureCloud. Download it to view the
                    contents.
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Footer */}
        <footer className="mt-16 text-center text-sm text-muted-foreground">
          <p>
            © 2025. Built with{' '}
            <span className="text-destructive">❤</span> using{' '}
            <a
              href="https://caffeine.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-foreground hover:underline"
            >
              caffeine.ai
            </a>
          </p>
        </footer>
      </div>
    </div>
  );
}
