import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Cloud, Lock, Shield, Upload } from 'lucide-react';

export default function LoginPage() {
  const { login, isLoggingIn } = useInternetIdentity();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <header className="mb-16 text-center">
          <div className="mb-4 flex justify-center">
            <div className="rounded-2xl bg-primary/10 p-4">
              <Cloud className="h-12 w-12 text-primary" />
            </div>
          </div>
          <h1 className="mb-2 text-4xl font-bold tracking-tight">SecureCloud</h1>
          <p className="text-lg text-muted-foreground">Your private cloud storage solution</p>
        </header>

        {/* Main Content */}
        <div className="mx-auto max-w-6xl">
          <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
            {/* Login Card */}
            <div className="flex items-center justify-center">
              <Card className="w-full max-w-md shadow-lg">
                <CardHeader className="space-y-1 text-center">
                  <CardTitle className="text-2xl">Welcome Back</CardTitle>
                  <CardDescription>
                    Sign in with Internet Identity to access your secure storage
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button
                    onClick={login}
                    disabled={isLoggingIn}
                    className="w-full"
                    size="lg"
                  >
                    {isLoggingIn ? (
                      <>
                        <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                        Signing in...
                      </>
                    ) : (
                      <>
                        <Lock className="mr-2 h-4 w-4" />
                        Sign in with Internet Identity
                      </>
                    )}
                  </Button>
                  <p className="text-center text-xs text-muted-foreground">
                    New users will be automatically registered
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Features */}
            <div className="space-y-6">
              <div>
                <h2 className="mb-6 text-2xl font-semibold">Why SecureCloud?</h2>
                <div className="space-y-4">
                  <FeatureItem
                    icon={<Shield className="h-5 w-5" />}
                    title="Private & Secure"
                    description="Your files are encrypted and only accessible to you. No one else can view or access your data."
                  />
                  <FeatureItem
                    icon={<Upload className="h-5 w-5" />}
                    title="Easy Upload"
                    description="Drag and drop files or click to upload. Support for all file types including documents, images, and videos."
                  />
                  <FeatureItem
                    icon={<Cloud className="h-5 w-5" />}
                    title="Decentralized Storage"
                    description="Built on the Internet Computer blockchain for maximum security and reliability."
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-16 text-center text-sm text-muted-foreground">
          <p>
            © 2025. Built with{' '}
            <span className="text-destructive">❤</span> using{' '}
            <a
              href="https://caffeine.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-foreground hover:underline"
            >
              caffeine.ai
            </a>
          </p>
        </footer>
      </div>
    </div>
  );
}

function FeatureItem({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="flex gap-4">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
        {icon}
      </div>
      <div>
        <h3 className="mb-1 font-semibold">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}
