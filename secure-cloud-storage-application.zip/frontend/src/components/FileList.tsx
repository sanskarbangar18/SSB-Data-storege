import { useState } from 'react';
import type { FileMetadata } from '../backend';
import FileItem from './FileItem';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Grid3x3, List } from 'lucide-react';

interface FileListProps {
  files: FileMetadata[];
}

export default function FileList({ files }: FileListProps) {
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');

  // Sort files by upload timestamp (newest first)
  const sortedFiles = [...files].sort((a, b) => {
    const timeA = Number(a.uploadTimestamp);
    const timeB = Number(b.uploadTimestamp);
    return timeB - timeA;
  });

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'list' | 'grid')}>
          <TabsList>
            <TabsTrigger value="list" className="gap-2">
              <List className="h-4 w-4" />
              <span className="hidden sm:inline">List</span>
            </TabsTrigger>
            <TabsTrigger value="grid" className="gap-2">
              <Grid3x3 className="h-4 w-4" />
              <span className="hidden sm:inline">Grid</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {viewMode === 'list' ? (
        <div className="space-y-2">
          {sortedFiles.map((file) => (
            <FileItem key={file.id} file={file} viewMode="list" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {sortedFiles.map((file) => (
            <FileItem key={file.id} file={file} viewMode="grid" />
          ))}
        </div>
      )}
    </div>
  );
}
