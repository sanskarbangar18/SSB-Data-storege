import { Upload, Cloud } from 'lucide-react';

export default function EmptyState() {
  return (
    <div className="rounded-lg border border-dashed p-12 text-center">
      <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
        <Cloud className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="mb-2 text-lg font-semibold">No files yet</h3>
      <p className="mb-4 text-sm text-muted-foreground">
        Upload your first file to get started
      </p>
      <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
        <Upload className="h-4 w-4" />
        <span>Use the upload zone above to add files</span>
      </div>
    </div>
  );
}
