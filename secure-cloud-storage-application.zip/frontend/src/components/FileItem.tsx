import { useState } from 'react';
import type { FileMetadata } from '../backend';
import { useDeleteFile, useGenerateShareLink } from '../hooks/useQueries';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  FileText,
  Image,
  Video,
  Music,
  Archive,
  File,
  Download,
  Trash2,
  MoreVertical,
  Share2,
  Copy,
  Check,
} from 'lucide-react';
import { toast } from 'sonner';

interface FileItemProps {
  file: FileMetadata;
  viewMode: 'list' | 'grid';
}

export default function FileItem({ file, viewMode }: FileItemProps) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  const [copied, setCopied] = useState(false);
  const { mutate: deleteFile, isPending: isDeleting } = useDeleteFile();
  const { mutate: generateShareLink, isPending: isGeneratingLink } = useGenerateShareLink();

  const formatFileSize = (bytes: bigint) => {
    const numBytes = Number(bytes);
    if (numBytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(numBytes) / Math.log(k));
    return Math.round((numBytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const formatDate = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000); // Convert nanoseconds to milliseconds
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith('image/')) return <Image className="h-5 w-5" />;
    if (fileType.startsWith('video/')) return <Video className="h-5 w-5" />;
    if (fileType.startsWith('audio/')) return <Music className="h-5 w-5" />;
    if (fileType.includes('pdf')) return <FileText className="h-5 w-5" />;
    if (fileType.includes('zip') || fileType.includes('rar'))
      return <Archive className="h-5 w-5" />;
    return <File className="h-5 w-5" />;
  };

  const getFileIconColor = (fileType: string) => {
    if (fileType.startsWith('image/')) return 'text-blue-500';
    if (fileType.startsWith('video/')) return 'text-purple-500';
    if (fileType.startsWith('audio/')) return 'text-green-500';
    if (fileType.includes('pdf')) return 'text-red-500';
    if (fileType.includes('zip') || fileType.includes('rar')) return 'text-yellow-500';
    return 'text-muted-foreground';
  };

  const handleDownload = async () => {
    try {
      const response = await fetch(`/blobs/${file.id}`);
      if (!response.ok) {
        throw new Error('Failed to download file');
      }
      
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('Failed to download file');
    }
  };

  const handleDelete = () => {
    deleteFile(file.id, {
      onSuccess: () => {
        setShowDeleteDialog(false);
      },
    });
  };

  const handleShare = () => {
    if (file.publicShareId) {
      // Already has a share link, just show it
      setShowShareDialog(true);
    } else {
      // Generate a new share link
      generateShareLink(file, {
        onSuccess: () => {
          setShowShareDialog(true);
        },
      });
    }
  };

  const getShareUrl = () => {
    if (!file.publicShareId) return '';
    return `${window.location.origin}/share/${file.publicShareId}`;
  };

  const handleCopyLink = async () => {
    const shareUrl = getShareUrl();
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success('Link copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
      toast.error('Failed to copy link');
    }
  };

  if (viewMode === 'grid') {
    return (
      <>
        <Card className="overflow-hidden transition-shadow hover:shadow-md">
          <div className="p-4">
            <div className="mb-3 flex items-start justify-between">
              <div className={`rounded-lg bg-muted p-3 ${getFileIconColor(file.fileType)}`}>
                {getFileIcon(file.fileType)}
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={handleDownload}>
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleShare} disabled={isGeneratingLink}>
                    <Share2 className="mr-2 h-4 w-4" />
                    {file.publicShareId ? 'View Share Link' : 'Generate Share Link'}
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => setShowDeleteDialog(true)}
                    className="text-destructive"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="space-y-1">
              <p className="truncate font-medium" title={file.filename}>
                {file.filename}
              </p>
              <p className="text-xs text-muted-foreground">{formatFileSize(file.filesize)}</p>
              <p className="text-xs text-muted-foreground">{formatDate(file.uploadTimestamp)}</p>
              {file.publicShareId && (
                <div className="flex items-center gap-1 text-xs text-primary">
                  <Share2 className="h-3 w-3" />
                  <span>Shared</span>
                </div>
              )}
            </div>
          </div>
        </Card>

        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete File</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{file.filename}"? This action cannot be undone.
                {file.publicShareId && ' The share link will also be invalidated.'}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDelete}
                disabled={isDeleting}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {isDeleting ? 'Deleting...' : 'Delete'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Share File</DialogTitle>
              <DialogDescription>
                Anyone with this link can view and download this file without signing in.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={getShareUrl()}
                  readOnly
                  className="flex-1 rounded-md border bg-muted px-3 py-2 text-sm"
                />
                <Button onClick={handleCopyLink} size="icon" variant="outline">
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                This link will remain valid until you delete the file.
              </p>
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <>
      <Card className="transition-shadow hover:shadow-md">
        <div className="flex items-center gap-4 p-4">
          <div className={`rounded-lg bg-muted p-3 ${getFileIconColor(file.fileType)}`}>
            {getFileIcon(file.fileType)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <p className="truncate font-medium" title={file.filename}>
                {file.filename}
              </p>
              {file.publicShareId && (
                <div className="flex items-center gap-1 text-xs text-primary">
                  <Share2 className="h-3 w-3" />
                  <span>Shared</span>
                </div>
              )}
            </div>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span>{formatFileSize(file.filesize)}</span>
              <span>{formatDate(file.uploadTimestamp)}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={handleDownload}>
              <Download className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleShare}
              disabled={isGeneratingLink}
            >
              <Share2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowDeleteDialog(true)}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete File</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{file.filename}"? This action cannot be undone.
              {file.publicShareId && ' The share link will also be invalidated.'}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share File</DialogTitle>
            <DialogDescription>
              Anyone with this link can view and download this file without signing in.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={getShareUrl()}
                readOnly
                className="flex-1 rounded-md border bg-muted px-3 py-2 text-sm"
              />
              <Button onClick={handleCopyLink} size="icon" variant="outline">
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              This link will remain valid until you delete the file.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
