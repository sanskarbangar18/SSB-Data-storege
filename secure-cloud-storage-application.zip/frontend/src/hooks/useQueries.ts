import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { useInternetIdentity } from './useInternetIdentity';
import type { FileMetadata } from '../backend';
import { toast } from 'sonner';

export function useRegisterUser() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      await actor.register([]);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userFiles'] });
    },
    onError: (error: Error) => {
      // Silently handle "User already exists" error
      if (!error.message.includes('User already exists')) {
        toast.error(`Registration failed: ${error.message}`);
      }
    },
  });
}

export function useGetUserFiles() {
  const { actor, isFetching: actorFetching } = useActor();
  const { identity } = useInternetIdentity();

  return useQuery<FileMetadata[]>({
    queryKey: ['userFiles'],
    queryFn: async () => {
      if (!actor || !identity) return [];
      const principal = identity.getPrincipal();
      return actor.getUserFiles(principal);
    },
    enabled: !!actor && !actorFetching && !!identity,
  });
}

export function useUploadFile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();
  const { mutate: registerUser } = useRegisterUser();

  return useMutation({
    mutationFn: async ({
      file,
      onProgress,
    }: {
      file: File;
      onProgress?: (percentage: number) => void;
    }) => {
      if (!actor) throw new Error('Actor not available');

      // Register user if not already registered (will silently fail if already exists)
      registerUser();

      // Convert file to bytes
      const arrayBuffer = await file.arrayBuffer();
      const bytes = new Uint8Array(arrayBuffer);

      // Upload to blob storage endpoint
      const formData = new FormData();
      formData.append('file', new Blob([bytes], { type: file.type }));

      // Simulate progress for now
      if (onProgress) {
        onProgress(50);
      }

      const response = await fetch('/blobs', {
        method: 'POST',
        body: bytes,
        headers: {
          'Content-Type': file.type || 'application/octet-stream',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to upload file');
      }

      if (onProgress) {
        onProgress(100);
      }

      // Extract blob ID from response
      const blobUrl = response.headers.get('Location') || response.url;
      const fileId = blobUrl.split('/').pop() || '';

      // Save file metadata
      await actor.addOrUpdateFile(
        fileId,
        file.name,
        BigInt(file.size),
        file.type || 'application/octet-stream',
        null
      );

      return fileId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userFiles'] });
      toast.success('File uploaded successfully');
    },
    onError: (error: Error) => {
      toast.error(`Upload failed: ${error.message}`);
    },
  });
}

export function useDeleteFile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (fileId: string) => {
      if (!actor) throw new Error('Actor not available');
      const result = await actor.removeFileFromUser(fileId);
      if (!result) {
        throw new Error('Failed to delete file');
      }
      
      // Also delete from blob storage
      try {
        await fetch(`/blobs/${fileId}`, {
          method: 'DELETE',
        });
      } catch (error) {
        console.warn('Failed to delete blob:', error);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userFiles'] });
      toast.success('File deleted successfully');
    },
    onError: (error: Error) => {
      toast.error(`Delete failed: ${error.message}`);
    },
  });
}

export function useGetFileMetadata(fileId: string) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<FileMetadata>({
    queryKey: ['fileMetadata', fileId],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getFileMetadata(fileId);
    },
    enabled: !!actor && !actorFetching && !!fileId,
  });
}

export function useGenerateShareLink() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (file: FileMetadata) => {
      if (!actor) throw new Error('Actor not available');
      
      // Generate a unique share ID
      const shareId = `${file.id}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      
      // Update file metadata with share ID
      await actor.addOrUpdateFile(
        file.id,
        file.filename,
        file.filesize,
        file.fileType,
        shareId
      );

      return shareId;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userFiles'] });
      toast.success('Share link generated successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to generate share link: ${error.message}`);
    },
  });
}

export function useGetPublicFileMetadata(shareId: string) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<FileMetadata | null>({
    queryKey: ['publicFileMetadata', shareId],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getFileMetadataByShareId(shareId);
    },
    enabled: !!actor && !actorFetching && !!shareId,
    retry: false,
  });
}

export function useGetFileIdByShareId(shareId: string) {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<string | null>({
    queryKey: ['fileIdByShareId', shareId],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getFileIdByShareId(shareId);
    },
    enabled: !!actor && !actorFetching && !!shareId,
    retry: false,
  });
}
