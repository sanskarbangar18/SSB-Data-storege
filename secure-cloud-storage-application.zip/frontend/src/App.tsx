import { useInternetIdentity } from './hooks/useInternetIdentity';
import { ThemeProvider } from 'next-themes';
import { Toaster } from '@/components/ui/sonner';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import PublicFilePage from './pages/PublicFilePage';
import { Loader2 } from 'lucide-react';

export default function App() {
  const { identity, isInitializing } = useInternetIdentity();
  const isAuthenticated = !!identity;

  // Check if we're on a public share route
  const path = window.location.pathname;
  const isPublicShareRoute = path.startsWith('/share/');

  // Show loading state while initializing (but not for public routes)
  if (isInitializing && !isPublicShareRoute) {
    return (
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <div className="flex h-screen items-center justify-center bg-background">
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Initializing...</p>
          </div>
        </div>
        <Toaster />
      </ThemeProvider>
    );
  }

  // Handle public share routes (no authentication required)
  if (isPublicShareRoute) {
    const shareId = path.split('/share/')[1];
    return (
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <PublicFilePage shareId={shareId} />
        <Toaster />
      </ThemeProvider>
    );
  }

  // Show login page if not authenticated
  if (!isAuthenticated) {
    return (
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <LoginPage />
        <Toaster />
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <DashboardPage />
      <Toaster />
    </ThemeProvider>
  );
}
