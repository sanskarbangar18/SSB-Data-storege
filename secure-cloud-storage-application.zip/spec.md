# Secure Cloud Storage Application

## Overview
A secure cloud storage application that allows multiple users to upload, manage, and download their files privately using Internet Identity authentication. Users can also generate public share links for selective file sharing.

## Authentication
- Users register and log in using Internet Identity
- Each user has a private, isolated storage space
- Only authenticated users can access the application dashboard
- Public file access is available through share links without authentication

## File Management Features
- **Upload**: Users can upload various file types (PDFs, images, videos, documents, etc.)
- **View**: Users can see a list of their uploaded files with basic metadata (filename, size, upload date)
- **Download**: Users can download their files in original quality
- **Delete**: Users can remove files from their storage
- **Share**: Users can generate unique public share links for any uploaded file

## Public File Sharing
- Users can generate unique, permanent share links for any of their files
- Share links remain valid indefinitely until the file is deleted by the owner
- Public access through share links requires no authentication
- Each file has a unique share ID for secure public access
- Only files with generated share links are publicly accessible
- All other files remain private and require user authentication

## Privacy and Security
- Each user's files are completely private and isolated by default
- Files are only accessible to the user who uploaded them, unless shared publicly
- No user can view or access another user's private files
- Public sharing is opt-in per file through share link generation

## Backend Data Storage
- User profiles and authentication data
- File metadata (filename, size, upload timestamp, file type)
- Share link data (unique share IDs, associated file mappings)
- Mapping between users and their files
- Files are stored using Caffeine blob storage for secure file handling

## Backend Operations
- User registration and authentication via Internet Identity
- File upload processing and storage
- File metadata management
- File retrieval and download (both private and public)
- File deletion
- User file listing
- Share link generation and management
- Public file access via share IDs

## User Interface
- Login/registration page with Internet Identity integration
- Dashboard showing user's uploaded files
- File upload interface with drag-and-drop support
- File management interface with view, download, delete, and share options
- Share link generation and copying functionality for each file
- Public file viewer/download page accessible via share links
- Simple, clean design focused on functionality
- All content displayed in English
